# 5985,5986 WinRM

Basic Commands
```shell
nmap -sV -sC 10.129.201.248 -p5985,5986 --disable-arp-ping -n
```

Evil-winrm
```shell
evil-winrm -i 10.129.201.248 -u Cry0l1t3 -p P455w0rD!
```

